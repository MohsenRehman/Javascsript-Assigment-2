// // String
let Name ="Mohsen Rehman"
console.log(Name);
console.log(typeof Name);

// // Number
let experince_in_year = 15;
console.log(experince_in_year);
console.log(typeof experince_in_year);
 
// // Boolean
let is_man =true;
console.log(is_man);
console.log(typeof is_man);

// // undefined
let length;
console.log(length);
console.log(typeof length);

// // null
let id = null;
console.log(id);
console.log(typeof id);

// // Convert Data Types
// // String to Number
let city = "Multan";
let num = Number(city);
console.log(num);
console.log(typeof num);
// // it gives NaN because i think in js String is not converted to Number

// // number to string
let wight = 60;
let text = String(wight)
console.log(text);
console.log(typeof text);

// // String to boolean
let country = "China"
let boll = Boolean(country)
console.log(boll);
console.log(typeof boll);
// if we pass the empty string so they return the false 

let abc = "cdf"
let nam = Number(abc)
console.log(nam);
console.log(typeof nam);
// i also check this above in step 4 , thay show the NaN because in js string in not converted into the Number and its show datatype is number.

let a = 0;
let b = Boolean(a)
console.log(b);
console.log(typeof b);
// it give false because in programming language 0 means off / false.

let c = 1;
let d = Boolean(c)
console.log(d);
console.log(typeof d);
// it give true because in programming language 1 means om / true.



